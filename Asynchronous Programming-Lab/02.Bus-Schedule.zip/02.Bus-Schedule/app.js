function solve() {
    let text = document.getElementById('info')
    let departBtn = document.getElementById('depart')
    let arriveBtn = document.getElementById('arrive')
    let url = 'http://localhost:3030/jsonstore/bus/schedule'
    let currentId = 'depot'

    function depart() {
        fetch(`${url}/${currentId}`)
        .then(res => res.json())
        .then(date =>{
            text.textContent = `Next stop ${date.name}`
            departBtn.disabled = true
            arriveBtn.disabled = false
        })
    }

    async function arrive() {
        fetch(`${url}/${currentId}`)
        .then(res => res.json())
        .then(date =>{
            text.textContent = `Arriving at  ${date.name}`
            currentId = date.next
            departBtn.disabled = false
            arriveBtn.disabled = true
        })
    }

    return {
        depart,
        arrive
    };
}

let result = solve();